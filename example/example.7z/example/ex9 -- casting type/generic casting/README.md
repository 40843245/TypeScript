# NOTICE
> [!CAUTION]
> Generic casting will not work with TSX, such as when working on React files.