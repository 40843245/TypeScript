let x: unknown = 'hello';
console.log((<string>x).length);