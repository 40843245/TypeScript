# NOTICE
> [!NOTE]
> There are no overloading in JavaScript and in TypeScript.
>
> To simulate the behavior in JavaScript and TypeScript,
>
> define a function or method and check the value of argument is undefined or NOT in the function definition.

> Stated more in [svick's answer at `How to do method overloading in TypeScript?`](https://stackoverflow.com/questions/12688275/how-to-do-method-overloading-in-typescript) 
