# ReturnType 
## intro
`ReturnType` extracts the return type of a function type.

## reference
[`ReturnType`](https://www.w3schools.com/typescript/typescript_utility_types.php)