# Pick 
## intro
`Pick` removes all but the specified keys from an object type.

## reference
[`Pick`](https://www.w3schools.com/typescript/typescript_utility_types.php)