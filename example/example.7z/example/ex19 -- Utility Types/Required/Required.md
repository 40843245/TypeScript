# Partial 
## intro
Required changes all the properties in an object to be required.

## reference
[`Required`](https://www.w3schools.com/typescript/typescript_utility_types.php)