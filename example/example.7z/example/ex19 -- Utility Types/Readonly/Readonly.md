# Readonly 
## intro
`Readonly` is used to create a new type where all properties are readonly, meaning they cannot be modified once assigned a value.

## reference
[`Readonly`](https://www.w3schools.com/typescript/typescript_utility_types.php)