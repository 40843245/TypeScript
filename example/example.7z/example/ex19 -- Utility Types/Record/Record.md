# Partial 
## intro
Record is a shortcut to defining an object type with a specific key type and value type.

## equivalent
`Record<string, number>` is equivalent to `{ [key: string]: number }`

## reference
[`Record`](https://www.w3schools.com/typescript/typescript_utility_types.php)