# Partial 
## intro
Partial changes all the properties in an object to be optional.

## reference
[`Partial`](https://www.w3schools.com/typescript/typescript_utility_types.php)