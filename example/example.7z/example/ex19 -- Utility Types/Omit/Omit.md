# Omit 
## intro
`Omit` removes keys from an object type.

## reference
[`Omit`](https://www.w3schools.com/typescript/typescript_utility_types.php)