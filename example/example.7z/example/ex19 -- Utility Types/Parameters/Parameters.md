# Parameters 
## intro
`Parameters` extracts the parameter types of a function type as an array.

## reference
[`Parameters`](https://www.w3schools.com/typescript/typescript_utility_types.php)