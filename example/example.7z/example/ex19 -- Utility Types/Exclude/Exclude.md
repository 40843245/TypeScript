# Exclude 
## intro
`Exclude` removes types from a union.

## reference
[`Exclude`](https://www.w3schools.com/typescript/typescript_utility_types.php)