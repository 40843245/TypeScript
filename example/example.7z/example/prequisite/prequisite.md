# TypeScript
## prequisite
It's assumed that you are familiar with `JavaScript`.

For more details about JavaScript, see [`JavaScript repo`](https://github.com/40843245/JS)