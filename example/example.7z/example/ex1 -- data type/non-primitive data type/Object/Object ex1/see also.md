# see also
See [`Object in Javascript`](https://www.w3schools.com/js/js_objects.asp) for more details.