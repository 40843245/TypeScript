# NOTICE
> [!NOTE]
> Technically, you can mix and match string and numeric enum values, but it is recommended not to do so.