enum Direction {
    North = 1,
    East,
    South,
    West
};

let currentDirection = Direction.North;
console.log(currentDirection); // 1
currentDirection = Direction.East;
console.log(currentDirection); // 2
currentDirection = Direction.South;
console.log(currentDirection); // 3
currentDirection = Direction.West;
console.log(currentDirection); // 4

