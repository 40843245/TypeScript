enum Direction {
    North,
    East,
    South,
    West
};

let currentDirection = Direction.North;
console.log(currentDirection); // 0
currentDirection = Direction.East;
console.log(currentDirection); // 1
currentDirection = Direction.South;
console.log(currentDirection); // 2
currentDirection = Direction.West;
console.log(currentDirection); // 3

