enum Direction {
    North,
    East = "East",
    South = "South",
    West = "West"
}; 
console.log(Direction.North); // 0
console.log(Direction.West); // "West"