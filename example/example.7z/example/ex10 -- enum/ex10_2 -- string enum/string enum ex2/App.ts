enum Direction {
    North = "North",
    East = "East",
    South = "South",
    West = "West"
}; 
console.log(Direction.North); // "North"
console.log(Direction.West); // "West"