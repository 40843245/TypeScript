/*
    error member `West` must have initializers
*/
enum Direction {
    North = "North",
    East = "East",
    South = "South",
    West 
}; 
console.log(Direction.North); 
console.log(Direction.West); 