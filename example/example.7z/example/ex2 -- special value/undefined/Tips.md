# Tip
> [!TIPS]
> `undefined` of a variable indicates the variable is declared but NOT defined.
>
> It has same behaves in JavaScript.

