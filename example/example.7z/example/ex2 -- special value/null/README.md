# NOTICE
> [!CAUTION]
> By default `null` and `undefined` handling is disabled, and can be enabled by setting `strictNullChecks` to true in `tsconfig.json` file.