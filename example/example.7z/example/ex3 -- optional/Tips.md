# Tip
> [!TIPS]
> If you are familiar with `null safety with optional operator` -- `?.` in Kotlin, 
>
> you can quickly understand what `?` means.