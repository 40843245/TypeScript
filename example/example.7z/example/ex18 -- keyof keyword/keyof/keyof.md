# keyof
## introduction
`keyof` is a keyword in TypeScript which is used to extract the key type from an object type.

## reference
[`keyof`](https://www.w3schools.com/typescript/typescript_keyof.php)