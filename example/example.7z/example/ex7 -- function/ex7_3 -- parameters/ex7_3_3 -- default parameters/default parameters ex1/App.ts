function pow(value: number, exponent: number = 10) {
    return value ** exponent;
}