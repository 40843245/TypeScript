function divide({ dividend, divisor }: { dividend: number, divisor: number }) {
    return dividend / divisor;
}