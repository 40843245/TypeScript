function getTime(): number {
    return new Date().getTime();
}

const currentTime: number = getTime();