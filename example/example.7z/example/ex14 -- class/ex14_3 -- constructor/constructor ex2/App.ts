class Animal {
    /// name is public member.
    /// it is a shorthand of example in `../constructor ex2/App.ts`
    constructor(public name:string){

    }
}

const eric = new Animal("Eric");