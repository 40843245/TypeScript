class Animal {
    name:string;

    constructor(name:string){
        this.name = name;
    }
}

const eric = new Animal("Eric");