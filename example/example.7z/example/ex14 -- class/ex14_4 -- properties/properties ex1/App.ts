class Animal {
    name: string;
}

const eric = new Animal();
eric.name = "Eric";