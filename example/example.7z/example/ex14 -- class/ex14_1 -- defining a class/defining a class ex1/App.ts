class Animal {
    name: string;
}