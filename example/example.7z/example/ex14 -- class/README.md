# NOTICE
> [!NOTE]
> Although TypeScript is based on JavaScript,
>
> there are slightly difference between syntax of class in TypeScript and JavaScript.